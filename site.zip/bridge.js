/*
 * PokéBonk 离线版 · 本地后端（Android WebView 版）
 * 把 server.py 的账号 / 存档 / 排行榜 / 战队逻辑移植到浏览器端，
 * 数据保存在 localStorage，静态资源由原生层拦截返回。
 */
(function () {
  'use strict';
  if (window.__pbBridge) return;
  window.__pbBridge = true;

  var KEY = 'pb.local.state.v2';
  var CLAN_COST = 2000;
  var CLAN_MAX = 100;
  var CLAN_START = 30;
  var SEASON_START = 1792081800000;

  // ------------------------------------------------------------- 工具
  function now() { return Date.now(); }

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function randId(n) {
    var s = '', c = 'abcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = 0; i < n; i++) s += c[(Math.random() * c.length) | 0];
    return s;
  }

  function seasonInfo() {
    return {
      n: 1, name: 'GEN 1', start: SEASON_START,
      end: SEASON_START + 30 * 86400000, live: true,
      dust: 1, message: '', next: null
    };
  }

  function defaultProfile(name) {
    return {
      v: 1, name: name, created: now(), stardust: 0, totalStardust: 0,
      unlocked: [], league: [], starter: 0, forms: [], research: {},
      captured: {}, seen: [], shinies: [], skins: [], lab: {},
      biomes: { forest: 0 }, quests: {}, counters: {}, runs: [],
      best: {}, times: {}, kills: {}, medals: {}, endless: {},
      settings: {
        master: 0.8, music: 0.5, sfx: 0.7, cries: 0.6, quality: 'high',
        aimMode: 'auto', sensitivity: 1, invertY: false, damageNumbers: true,
        floatText: true, shakeOn: true, screenShake: 1, fov: 70,
        showFps: false, reduceFlashes: false, pixel: 0, muteHidden: true,
        hudScale: 1, hudOpacity: 1, showMinimap: true, showLadder: true,
        showToasts: true, showStreak: true, fxOpacity: 1, fixedStick: false
      },
      lastSpecies: 4, lastBiome: 'forest', banished: [],
      itemsOwned: [], itemsOff: [],
      daily: { idx: 0, ids: [], prog: [0, 0, 0], claimed: [0, 0, 0, 0], rerolls: 0 },
      weekly: { idx: 0, ids: [], prog: [0, 0, 0], claimed: [0, 0, 0, 0], rerolls: 0 },
      dailyStreak: { last: 0, n: 0 }, bag: {},
      avatar: '', frame: '', title: '', cosmetics: []
    };
  }

  // ------------------------------------------------------------- 状态
  var S = null;

  function load() {
    if (S) return S;
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) S = JSON.parse(raw);
    } catch (e) { S = null; }
    if (!S || typeof S !== 'object') S = { version: 2, accounts: {}, clans: {}, guest_id: null };
    S.accounts = S.accounts || {};
    S.clans = S.clans || {};
    for (var id in S.accounts) {
      var a = S.accounts[id];
      if (!a.profile) a.profile = defaultProfile(a.name || '训练家');
      for (var k in defaultProfile('')) {
        if (!(k in a.profile)) a.profile[k] = clone(defaultProfile('')[k]);
      }
    }
    return S;
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { }
  }

  function accounts() { return Object.keys(load().accounts).map(function (k) { return S.accounts[k]; }); }

  function findByToken(tok) {
    if (!tok) return null;
    var list = accounts();
    for (var i = 0; i < list.length; i++) if (list[i].token === tok) return list[i];
    return null;
  }

  function findByName(name) {
    var low = (name || '').trim().toLowerCase();
    var list = accounts();
    for (var i = 0; i < list.length; i++) {
      if ((list[i].name || '').trim().toLowerCase() === low) return list[i];
    }
    return null;
  }

  function ensureGuest() {
    var s = load();
    if (s.guest_id && s.accounts[s.guest_id]) return s.accounts[s.guest_id];
    var list = accounts();
    for (var i = 0; i < list.length; i++) {
      if (list[i].guest) { s.guest_id = list[i].id; return list[i]; }
    }
    var acc = newAccount('离线玩家', true, null);
    s.guest_id = acc.id;
    save();
    return acc;
  }

  function newAccount(name, guest, pwHash, salt) {
    var s = load();
    var acc = {
      id: randId(12), name: name, guest: !!guest,
      token: randId(28), created: now(), lastSeen: now(),
      clan: null, pw: pwHash || null, salt: salt || null,
      profile: defaultProfile(name)
    };
    s.accounts[acc.id] = acc;
    return acc;
  }

  // ------------------------------------------------------------- 密码
  function hex(buf) {
    var o = '';
    var b = new Uint8Array(buf);
    for (var i = 0; i < b.length; i++) o += ('0' + b[i].toString(16)).slice(-2);
    return o;
  }

  function randSalt() {
    var a = new Uint8Array(8);
    (window.crypto || window.msCrypto).getRandomValues(a);
    return hex(a);
  }

  function hashPw(pw, salt) {
    var sub = window.crypto && window.crypto.subtle;
    if (!sub) {
      // 极端情况下退化为简单散列（仅本地存档用）
      var h = 0, str = salt + '|' + pw;
      for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
      return Promise.resolve('x' + (h >>> 0).toString(16));
    }
    var enc = new TextEncoder();
    return sub.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits'])
      .then(function (k) {
        return sub.deriveBits({
          name: 'PBKDF2', salt: enc.encode(salt), iterations: 120000, hash: 'SHA-256'
        }, k, 256);
      })
      .then(hex);
  }

  // ------------------------------------------------------------- 局结算
  function runPoints(rec) {
    var pts = parseInt(rec.kills || 0, 10);
    pts += parseInt(rec.stage || 1, 10) * 50;
    pts += parseInt(rec.tier || 0, 10) * 25;
    if (rec.victory) pts += 150;
    return pts;
  }

  function applyFinish(acc, result) {
    var p = acc.profile;
    result = result || {};
    var progress = result.progress || {};

    var counters = progress.counters || {};
    for (var k in counters) {
      p.counters[k] = (parseInt(p.counters[k] || 0, 10) || 0) + (parseInt(counters[k], 10) || 0);
    }
    if (!('runs' in counters)) {
      p.counters.runs = (parseInt(p.counters.runs || 0, 10) || 0) + 1;
    }
    var research = progress.research || {};
    for (var rk in research) {
      p.research[rk] = (parseFloat(p.research[rk] || 0) || 0) + (parseFloat(research[rk]) || 0);
    }
    ['seen', 'shinies', 'league', 'forms'].forEach(function (key) {
      var arr = p[key] || (p[key] = []);
      (progress[key] || []).forEach(function (v) {
        if (arr.indexOf(v) < 0) arr.push(v);
      });
    });

    var species = parseInt(result.species || 0, 10);
    var kills = parseInt(result.kills || 0, 10);
    var stage = parseInt(result.stage || 1, 10);
    var secs = parseFloat(result.time || 0);
    var gold = parseFloat((result.econ || {}).gold || 0);

    var dust = Math.floor(Math.min(3000, gold * 0.25)) + kills * 2 + stage * 40;
    p.stardust = (parseInt(p.stardust || 0, 10) || 0) + dust;
    p.totalStardust = (parseInt(p.totalStardust || 0, 10) || 0) + dust;

    if (species && p.seen.indexOf(species) < 0) p.seen.push(species);
    var biome = result.biome || p.lastBiome || 'forest';
    if (typeof biome === 'string') {
      p.biomes = p.biomes || {};
      p.biomes[biome] = Math.max(parseInt(p.biomes[biome] || 0, 10) || 0, stage);
    }

    var score = parseInt(result.score || 0, 10) || (kills * 10 + secs);
    var rec = {
      id: 'local-' + now(), date: now(), seed: result.seed || 0,
      ranked: !acc.guest, score: score,
      kills: kills, time: secs, damage: parseInt(result.damage || 0, 10),
      stage: stage, tier: parseInt(result.tier || 0, 10),
      species: species, finalSpecies: parseInt(result.finalSpecies || species || 0, 10),
      biome: biome, level: parseInt(result.level || 1, 10),
      victory: !!result.victory, mode: result.mode || 'standard',
      stardust: dust, season: seasonInfo()
    };
    p.runs = (p.runs || []).slice(-99).concat([rec]);
    p.best = p.best || {};
    if (score > (parseInt(p.best.score || 0, 10) || 0)) p.best.score = score;
    if (kills > (parseInt(p.best.kills || 0, 10) || 0)) p.best.kills = kills;
    if (secs > (parseFloat(p.best.time || 0) || 0)) p.best.time = secs;
    return rec;
  }

  // ------------------------------------------------------------- 排行榜
  function boardRun(acc, mode, species, biome, tier) {
    if (acc.guest) return null;
    var runs = acc.profile.runs || [], best = null;
    for (var i = 0; i < runs.length; i++) {
      var rec = runs[i];
      if (!rec) continue;
      var rmode = rec.mode || 'standard';
      if (mode === 'endless' ? rmode !== 'endless' : rmode === 'endless') continue;
      if (species != null &&
        parseInt(rec.species || 0, 10) !== species &&
        parseInt(rec.finalSpecies || 0, 10) !== species) continue;
      if (biome && rec.biome !== biome) continue;
      if (tier != null && parseInt(rec.tier || 0, 10) !== tier) continue;
      if (!best) { best = rec; continue; }
      if (mode === 'endless') {
        if (rec.time > best.time || (rec.time === best.time && rec.kills > best.kills)) best = rec;
      } else {
        if (rec.kills > best.kills || (rec.kills === best.kills && rec.time > best.time)) best = rec;
      }
    }
    return best;
  }

  function entryOf(acc, rec, rank, meId) {
    var p = acc.profile;
    var clan = S.clans[acc.clan || ''];
    return {
      id: acc.id, rank: rank, name: acc.name,
      tag: (clan && clan.tag) || null,
      title: p.title || null,
      avatar: p.avatar || '', frame: p.frame || '',
      species: parseInt(rec.finalSpecies || rec.species || 0, 10),
      skins: p.skins || [],
      kills: parseInt(rec.kills || 0, 10),
      time: parseFloat(rec.time || 0),
      score: parseInt(rec.score || 0, 10),
      me: acc.id === meId
    };
  }

  function playerBoard(meAcc, mode, species, biome, tier, limit) {
    var rows = [];
    var list = accounts();
    for (var i = 0; i < list.length; i++) {
      var rec = boardRun(list[i], mode, species, biome, tier);
      if (rec) rows.push({ acc: list[i], rec: rec });
    }
    rows.sort(function (a, b) {
      if (mode === 'endless') {
        return (b.rec.time - a.rec.time) || (b.rec.kills - a.rec.kills);
      }
      return (b.rec.kills - a.rec.kills) || (b.rec.time - a.rec.time);
    });
    var entries = rows.map(function (r, i) { return entryOf(r.acc, r.rec, i + 1, meAcc.id); });
    var me = null;
    for (var j = 0; j < entries.length; j++) {
      if (entries[j].me) {
        me = { rank: entries[j].rank, kills: entries[j].kills, time: entries[j].time, species: entries[j].species };
        break;
      }
    }
    var cutoff = null;
    if (entries.length) {
      var last = entries[entries.length - 1];
      cutoff = mode === 'endless' ? last.time : last.kills;
    }
    return {
      entries: entries.slice(0, limit || 20), me: me,
      players: entries.length, cutoff: cutoff, info: seasonInfo()
    };
  }

  function clanPoints(clan) {
    var total = 0;
    for (var aid in clan.members) {
      var acc = S.accounts[aid];
      if (!acc) continue;
      var best = boardRun(acc, 'kills', null, null, null);
      if (best) total += runPoints(best);
    }
    return total;
  }

  function clanMemberRows(clan) {
    var rows = [];
    for (var aid in clan.members) {
      var acc = S.accounts[aid];
      if (!acc) continue;
      var p = acc.profile, runs = p.runs || [], pts = 0;
      for (var i = 0; i < runs.length; i++) pts += runPoints(runs[i]);
      rows.push({
        id: aid, name: acc.name, role: clan.members[aid].role || 'member',
        avatar: p.avatar || '', frame: p.frame || '',
        species: parseInt(p.lastSpecies || 0, 10),
        skins: p.skins || [],
        joined: clan.members[aid].joined || now(),
        lastSeen: acc.lastSeen || now(),
        points: pts, runs: runs.length, total: pts
      });
    }
    var order = { leader: 0, officer: 1, member: 2 };
    rows.sort(function (a, b) {
      var d = (order[a.role] || 3) - (order[b.role] || 3);
      return d !== 0 ? d : (b.points - a.points);
    });
    return rows;
  }

  function clanPublic(meAcc, clan) {
    var rows = clanMemberRows(clan);
    var myRole = null;
    for (var i = 0; i < rows.length; i++) if (meAcc && rows[i].id === meAcc.id) myRole = rows[i].role;
    var points = clanPoints(clan);
    var all = [], cid;
    for (cid in S.clans) all.push([cid, clanPoints(S.clans[cid])]);
    all.sort(function (a, b) { return b[1] - a[1]; });
    var rank = null;
    for (var j = 0; j < all.length; j++) if (all[j][0] === clan.id) rank = j + 1;

    var requests = [];
    if (myRole === 'leader' || myRole === 'officer') {
      (clan.requests || []).forEach(function (rq) {
        var acc = S.accounts[rq.user];
        if (!acc) return;
        var p = acc.profile;
        requests.push({
          id: rq.id, created: rq.created, message: rq.message || '',
          user: {
            id: acc.id, name: acc.name, avatar: p.avatar || '', frame: p.frame || '',
            species: parseInt(p.lastSpecies || 0, 10), skins: p.skins || []
          }
        });
      });
    }
    var mineReq = null;
    (clan.requests || []).forEach(function (rq) {
      if (meAcc && rq.user === meAcc.id) mineReq = { created: rq.created };
    });

    return {
      id: clan.id, name: clan.name, tag: clan.tag,
      emblem: clan.emblem || {}, created: clan.created,
      max: clan.max || CLAN_START, access: clan.access || 'request',
      description: clan.description || '',
      me: myRole, members: rows, requests: requests,
      mine: { invite: null, request: mineReq },
      notice: clan.notice || null,
      noticeNext: clan.noticeNext || 0,
      cosmetics: clan.cosmetics || [],
      trophies: clan.trophies || [],
      season: { n: 1, points: points, rank: rank, clans: all.length, cutoff: null },
      all: { points: points, rank: rank },
      endless: null
    };
  }

  function clanBoard(meAcc, limit) {
    var rows = [], cid;
    for (cid in S.clans) rows.push([S.clans[cid], clanPoints(S.clans[cid])]);
    rows.sort(function (a, b) { return b[1] - a[1]; });
    var entries = [], meRow = null;
    rows.forEach(function (pair, i) {
      var clan = pair[0], pts = pair[1];
      var members = clanMemberRows(clan);
      var top = members[0] || null;
      var e = {
        rank: i + 1, id: clan.id, name: clan.name, tag: clan.tag,
        emblem: clan.emblem || {}, points: pts,
        members: Object.keys(clan.members).length,
        max: clan.max || CLAN_START,
        top: top ? { name: top.name, points: top.points } : null,
        me: !!(meAcc && meAcc.clan === clan.id)
      };
      entries.push(e);
      if (e.me) {
        meRow = { rank: i + 1, name: clan.name, tag: clan.tag, points: pts, emblem: clan.emblem || {} };
      }
    });
    return {
      entries: entries.slice(0, limit || 50), me: meRow, info: seasonInfo(),
      players: entries.length, clans: entries.length, cutoff: null
    };
  }

  // ------------------------------------------------------------- 响应
  function json(obj, status) {
    return Promise.resolve(new Response(JSON.stringify(obj), {
      status: status || 200,
      headers: { 'Content-Type': 'application/json' }
    }));
  }

  function fail(msg, status) { return json({ error: msg }, status || 400); }

  function empty() { return Promise.resolve(new Response(null, { status: 204 })); }

  // ------------------------------------------------------------- 路由
  var API = /^\/(status|auth\/|profile|runs|news$|records|seasons|leaderboard|mail|clans|friends|players|lab\/|items\/|quests\/|tasks\/|feedback)/;

  function handle(path, qs, method, body, token) {
    var acc = findByToken(token);

    // ---- 状态 / 账号
    if (path === '/status') {
      return json({
        maintenance: { on: false, title: '', message: '', eta: 0 },
        bypass: false, season: seasonInfo(),
        registration: { inviteOnly: false }
      });
    }
    if (path === '/auth/guest') {
      var g = ensureGuest(); save();
      return json({ id: g.id, name: g.name, token: g.token });
    }
    if (path === '/auth/me') {
      if (!acc) return fail('Sesión no válida.', 401);
      return json({ id: acc.id, name: acc.name, guest: acc.guest, created: acc.created });
    }
    if (path === '/auth/register') {
      var rn = String((body || {}).name || '').trim();
      var rp = String((body || {}).password || '');
      if (rn.length < 3) return fail('名称至少需要 3 个字符。');
      if (rn.length > 16) return fail('名称最多 16 个字符。');
      if (rp.length < 8) return fail('密码至少需要 8 个字符。');
      if (findByName(rn)) return fail('这个名称在本机已被使用。');
      var salt = randSalt();
      return hashPw(rp, salt).then(function (h) {
        var acc2 = newAccount(rn, false, h, salt);
        save();
        return json({ id: acc2.id, name: acc2.name, token: acc2.token });
      });
    }
    if (path === '/auth/login') {
      var ln = String((body || {}).name || '').trim();
      var lp = String((body || {}).password || '');
      var target = findByName(ln);
      if (!target || target.guest || !target.pw) return fail('名称或密码不正确。', 401);
      return hashPw(lp, target.salt).then(function (h) {
        if (h !== target.pw) return fail('名称或密码不正确。', 401);
        target.lastSeen = now(); save();
        return json({ id: target.id, name: target.name, token: target.token });
      });
    }
    if (path === '/auth/upgrade') {
      if (!acc) return fail('Sesión no válida.', 401);
      var un = String((body || {}).name || '').trim();
      var up = String((body || {}).password || '');
      if (un.length < 3) return fail('名称至少需要 3 个字符。');
      if (un.length > 16) return fail('名称最多 16 个字符。');
      if (up.length < 8) return fail('密码至少需要 8 个字符。');
      var other = findByName(un);
      if (other && other.id !== acc.id) return fail('这个名称在本机已被使用。');
      var s2 = randSalt();
      return hashPw(up, s2).then(function (h2) {
        acc.name = un; acc.guest = false; acc.salt = s2; acc.pw = h2;
        acc.profile.name = un; save();
        return json({ id: acc.id, name: acc.name, token: acc.token });
      });
    }
    if (path === '/auth/logout') return json({});

    // ---- 档案
    if (!acc) acc = ensureGuest();
    if (path === '/profile' && method === 'GET') return json({ profile: acc.profile });

    if (path === '/profile/prefs') {
      // 客户端整档回传：研究所升级 / 道具解锁 / 委托任务都由它先算好，
      // 这里整体接收（缺的字段补默认值），否则改动会被下一次请求覆盖。
      if (body && typeof body === 'object' &&
        ('stardust' in body || 'lab' in body || 'itemsOwned' in body || 'runs' in body)) {
        var prof = JSON.parse(JSON.stringify(body));
        var def2 = defaultProfile(acc.name);
        for (var dk in def2) if (!(dk in prof)) prof[dk] = def2[dk];
        prof.name = acc.name;
        prof.created = prof.created || acc.profile.created || now();
        acc.profile = prof;
        save();
      } else if (body && typeof body === 'object') {
        if (body.settings) {
          for (var sk in body.settings) acc.profile.settings[sk] = body.settings[sk];
        }
        ['lastSpecies', 'lastBiome', 'avatar', 'frame', 'title', 'skins'].forEach(function (k) {
          if (k in body) acc.profile[k] = body[k];
        });
        save();
      }
      return empty();
    }
    if (path === '/profile/starter') {
      var sid = parseInt((body || {}).id || 0, 10);
      acc.profile.starter = sid;
      acc.profile.lastSpecies = sid;
      if (sid) {
        if (acc.profile.seen.indexOf(sid) < 0) acc.profile.seen.push(sid);
        if (acc.profile.league.indexOf(sid) < 0) acc.profile.league.push(sid);
        if (acc.profile.unlocked.indexOf(sid) < 0) acc.profile.unlocked.push(sid);
        acc.profile.captured[sid] = now();
      }
      save();
      return json({ profile: acc.profile });
    }

    // ---- 对局
    if (path === '/runs' && method === 'POST') {
      return json({
        id: 'local-' + randId(8), seed: (Math.random() * 0x7fffffff) | 0,
        ranked: !acc.guest, boosts: [], offline: false, season: seasonInfo()
      });
    }
    if (/^\/runs\/[^/]+\/checkpoint$/.test(path)) return json({ ok: true });
    var fin = /^\/runs\/([^/]+)\/finish$/.exec(path);
    if (fin) {
      var rec = applyFinish(acc, (body || {}).result || {});
      save();
      return json({
        profile: acc.profile, record: rec, stardust: rec.stardust,
        ranked: rec.ranked, weekPb: false, medal: null
      });
    }

    // ---- 排行榜
    if (path === '/leaderboard') {
      var limit = parseInt(qs.get('limit') || '20', 10) || 20;
      var mode = (qs.get('mode') || 'kills').toLowerCase();
      var sp = qs.get('species');
      sp = sp === null || sp === '' ? null : parseInt(sp, 10);
      var biome = qs.get('biome') || null;
      var tier = qs.get('tier');
      tier = tier === null || tier === '' ? null : parseInt(tier, 10);
      return json(playerBoard(acc, mode, sp, biome, tier, limit));
    }
    if (path === '/leaderboard/pokemon') {
      return json({ entries: [], me: null, players: 0, cutoff: null, info: seasonInfo() });
    }
    if (path === '/records' || path === '/records/endless') return json([]);
    if (path === '/seasons/awards') return json([]);
    if (path === '/seasons/claim') return json({ profile: acc.profile });

    // ---- 战队
    if (path === '/clans/status') {
      var cid0 = acc.clan, cn = cid0 ? S.clans[cid0] : null;
      var ref = cn ? { id: cn.id, name: cn.name, tag: cn.tag, emblem: cn.emblem || {} } : null;
      var reqCount = 0;
      if (cn) {
        var role0 = (cn.members[acc.id] || {}).role;
        if (role0 === 'leader' || role0 === 'officer') reqCount = (cn.requests || []).length;
      }
      var pending = [];
      for (var c1 in S.clans) {
        (S.clans[c1].requests || []).forEach(function (rq) {
          if (rq.user === acc.id) {
            pending.push({
              clan: {
                id: S.clans[c1].id, name: S.clans[c1].name,
                tag: S.clans[c1].tag, emblem: S.clans[c1].emblem || {}
              },
              created: rq.created
            });
          }
        });
      }
      return json({ clan: ref, requests: reqCount, mail: 0, friends: 0, pending: pending });
    }

    if (path === '/clans/search') {
      var q = (qs.get('q') || '').trim().toLowerCase(), out = [];
      for (var c2 in S.clans) {
        var cc = S.clans[c2];
        if (q && cc.name.toLowerCase().indexOf(q) < 0 && cc.tag.toLowerCase().indexOf(q) < 0) continue;
        out.push({
          id: cc.id, name: cc.name, tag: cc.tag, emblem: cc.emblem || {},
          members: Object.keys(cc.members).length, max: cc.max || CLAN_START,
          points: clanPoints(cc), description: cc.description || '', access: cc.access || 'request'
        });
      }
      out.sort(function (a, b) { return b.points - a.points; });
      return json(out);
    }

    if (path === '/clans/board') return json(clanBoard(acc, 50));

    if (path === '/clans' && method === 'POST') {
      var nm = String((body || {}).name || '').trim();
      var tg = String((body || {}).tag || '').trim().toUpperCase();
      if (acc.clan) return fail('你已经在战队中了。');
      if (nm.length < 3 || nm.length > 24) return fail('战队名称需要 3~24 个字符。');
      if (tg.length < 2 || tg.length > 4) return fail('战队缩写需要 2~4 个字符。');
      var dup = false;
      for (var c3 in S.clans) {
        if (S.clans[c3].name.toLowerCase() === nm.toLowerCase() || S.clans[c3].tag === tg) dup = true;
      }
      if (dup) return fail('已有同名或同缩写的战队。');
      var p0 = acc.profile;
      if ((parseInt(p0.stardust || 0, 10) || 0) < CLAN_COST) return fail('需要 2000 星星沙子。');
      p0.stardust = parseInt(p0.stardust || 0, 10) - CLAN_COST;
      var ncid = randId(10);
      var clan = {
        id: ncid, name: nm, tag: tg, emblem: (body || {}).emblem || {},
        created: now(), max: CLAN_START, access: (body || {}).access || 'request',
        description: String((body || {}).description || '').slice(0, 160),
        members: {}, requests: [], notice: null, noticeNext: 0,
        cosmetics: ['deco:pioneer', 'sym:sprout'], trophies: []
      };
      clan.members[acc.id] = { role: 'leader', joined: now() };
      S.clans[ncid] = clan;
      acc.clan = ncid;
      save();
      return json({ clan: clanPublic(acc, clan), profile: p0 });
    }

    var mClan = /^\/clans\/([^/]+)$/.exec(path);
    if (mClan && method === 'GET') {
      var cl = S.clans[mClan[1]];
      if (!cl) return fail('没有这个战队。', 404);
      return json(clanPublic(acc, cl));
    }

    var mJoin = /^\/clans\/([^/]+)\/join$/.exec(path);
    if (mJoin && method === 'POST') {
      var cj = S.clans[mJoin[1]];
      if (!cj) return fail('没有这个战队。', 404);
      if (acc.guest) return fail('需要注册账号才能加入战队。');
      if (acc.clan) return fail('你已经在战队中了。');
      if (Object.keys(cj.members).length >= (cj.max || CLAN_START)) return fail('战队已满员。');
      var access = cj.access || 'request';
      if (access === 'invite') return fail('这个战队只接受邀请。');
      if (access === 'open') {
        cj.members[acc.id] = { role: 'member', joined: now() };
        acc.clan = cj.id; save();
        return json({ joined: true, clan: clanPublic(acc, cj) });
      }
      var msg = String((body || {}).message || '').slice(0, 120);
      cj.requests = cj.requests || [];
      var found = false;
      cj.requests.forEach(function (rq) {
        if (rq.user === acc.id) { rq.message = msg; rq.created = now(); found = true; }
      });
      if (!found) cj.requests.push({ id: randId(8), user: acc.id, message: msg, created: now() });
      save();
      return json({ joined: false, clan: clanPublic(acc, cj) });
    }

    var mWd = /^\/clans\/([^/]+)\/withdraw$/.exec(path);
    if (mWd && method === 'POST') {
      var cw = S.clans[mWd[1]];
      if (cw) {
        cw.requests = (cw.requests || []).filter(function (r) { return r.user !== acc.id; });
        save();
      }
      return json({ ok: true });
    }

    var mAns = /^\/clans\/([^/]+)\/requests\/([^/]+)\/answer$/.exec(path);
    if (mAns && method === 'POST') {
      var ca = S.clans[mAns[1]];
      if (!ca) return fail('没有这个战队。', 404);
      var myRole = (ca.members[acc.id] || {}).role;
      if (myRole !== 'leader' && myRole !== 'officer') return fail('没有权限。');
      var rq0 = null;
      (ca.requests || []).forEach(function (r) { if (r.id === mAns[2]) rq0 = r; });
      if (!rq0) return fail('这条申请已不存在。', 404);
      var accept = !!(body || {}).accept;
      ca.requests = ca.requests.filter(function (r) { return r.id !== rq0.id; });
      if (accept) {
        var tgt = S.accounts[rq0.user];
        if (tgt && !tgt.clan) {
          ca.members[tgt.id] = { role: 'member', joined: now() };
          tgt.clan = ca.id;
        }
      }
      save();
      return json(clanPublic(acc, ca));
    }

    if (path === '/clans/leave' && method === 'POST') {
      var cidL = acc.clan, cL = S.clans[cidL];
      if (!cL) return json({});
      var roleL = (cL.members[acc.id] || {}).role;
      delete cL.members[acc.id];
      acc.clan = null;
      var left = Object.keys(cL.members);
      if (!left.length) delete S.clans[cidL];
      else if (roleL === 'leader') cL.members[left[0]].role = 'leader';
      save();
      return json({});
    }

    if (path === '/clans/disband' && method === 'POST') {
      var cidD = acc.clan, cD = S.clans[cidD];
      if (!cD) return json({});
      var roleD = (cD.members[acc.id] || {}).role;
      if (roleD !== 'leader') return fail('只有队长可以解散战队。');
      if ((body || {}).confirm !== cD.tag) return fail('确认信息不正确。');
      for (var aid in cD.members) {
        var a2 = S.accounts[aid];
        if (a2) a2.clan = null;
      }
      delete S.clans[cidD];
      save();
      return json({});
    }

    if (path === '/clans/role' && method === 'POST') {
      var cR = S.clans[acc.clan];
      if (!cR) return fail('你不在任何战队中。');
      if ((cR.members[acc.id] || {}).role !== 'leader') return fail('只有队长可以调整职位。');
      var uid = (body || {}).user, role = (body || {}).role;
      if (!cR.members[uid] || ['leader', 'officer', 'member'].indexOf(role) < 0) return fail('数据无效。');
      if (role === 'leader') {
        cR.members[uid].role = 'leader';
        if (uid !== acc.id) cR.members[acc.id].role = 'officer';
      } else {
        cR.members[uid].role = role;
      }
      save();
      return json(clanPublic(acc, cR));
    }

    if (path === '/clans/kick' && method === 'POST') {
      var cK = S.clans[acc.clan];
      if (!cK) return fail('你不在任何战队中。');
      var myK = (cK.members[acc.id] || {}).role;
      var uidK = (body || {}).user, tgtK = cK.members[uidK];
      if (!tgtK) return fail('该成员已不在战队。');
      if (myK !== 'leader' && !(myK === 'officer' && tgtK.role === 'member')) return fail('没有权限。');
      delete cK.members[uidK];
      if (S.accounts[uidK]) S.accounts[uidK].clan = null;
      save();
      return json(clanPublic(acc, cK));
    }

    if (path === '/clans/invite' && method === 'POST') {
      var cI = S.clans[acc.clan];
      if (!cI) return fail('你不在任何战队中。');
      var myI = (cI.members[acc.id] || {}).role;
      if (myI !== 'leader' && myI !== 'officer') return fail('没有权限。');
      var tgtI = findByName((body || {}).name);
      if (!tgtI) return fail('本机没有这个训练家。');
      if (tgtI.clan) return fail('该训练家已在其他战队中。');
      if (Object.keys(cI.members).length >= (cI.max || CLAN_START)) return fail('战队已满员。');
      cI.members[tgtI.id] = { role: 'member', joined: now() };
      tgtI.clan = cI.id;
      save();
      return json(clanPublic(acc, cI));
    }

    if (path === '/clans/uninvite' && method === 'POST') return json({ ok: true });

    if (path === '/clans/notice' && method === 'POST') {
      var cN = S.clans[acc.clan];
      if (!cN) return fail('你不在任何战队中。');
      var myN = (cN.members[acc.id] || {}).role;
      if (myN !== 'leader' && myN !== 'officer') return fail('没有权限。');
      var text = String((body || {}).text || '').trim().slice(0, 280);
      if (!text) { cN.notice = null; save(); return json(clanPublic(acc, cN)); }
      var leftMs = (cN.noticeNext || 0) - now();
      if (leftMs > 0) return fail('刚发过公告，请稍后再试。');
      cN.notice = { by: acc.name, at: now(), text: text };
      cN.noticeNext = now() + 3600000;
      save();
      return json(clanPublic(acc, cN));
    }

    if (path === '/clans/settings' && method === 'POST') {
      var cS = S.clans[acc.clan];
      if (!cS) return fail('你不在任何战队中。');
      if ((cS.members[acc.id] || {}).role !== 'leader') return fail('只有队长可以修改设置。');
      if (body && ['open', 'request', 'invite'].indexOf(body.access) >= 0) cS.access = body.access;
      if (body && 'description' in body) cS.description = String(body.description).slice(0, 160);
      save();
      return json(clanPublic(acc, cS));
    }

    if (path === '/clans/emblem' && method === 'POST') {
      var cE = S.clans[acc.clan];
      if (!cE) return fail('你不在任何战队中。');
      if ((cE.members[acc.id] || {}).role !== 'leader') return fail('只有队长可以编辑徽记。');
      if ((body || {}).emblem) cE.emblem = body.emblem;
      save();
      return json(clanPublic(acc, cE));
    }

    if (path === '/clans/expand' && method === 'POST') {
      var cX = S.clans[acc.clan];
      if (!cX) return fail('你不在任何战队中。');
      var cur = cX.max || CLAN_START;
      if (cur >= CLAN_MAX) return fail('战队名额已达上限。');
      var cost = 500 + 250 * Math.round((cur - CLAN_START) / 10);
      var pX = acc.profile;
      if ((parseInt(pX.stardust || 0, 10) || 0) < cost) return fail('需要 ' + cost + ' 星星沙子。');
      pX.stardust = parseInt(pX.stardust || 0, 10) - cost;
      cX.max = cur + 10;
      save();
      return json({ clan: clanPublic(acc, cX), profile: pX });
    }

    if (/^\/clans\/[^/]+\/activity$/.test(path)) return json([]);

    // ---- 社交
    if (path === '/mail') return json([]);
    if (path === '/mail/read') return json({});
    if (/^\/mail\/[^/]+\/(answer|claim)$/.test(path)) return json({});
    if (path === '/friends') {
      if (method === 'GET') return json({ friends: [], incoming: [], outgoing: [] });
      return json({});
    }
    if (path.indexOf('/friends/') === 0) return json({});
    if (path.indexOf('/players/search') === 0) return json([]);

    // ---- 其余
    if (['/lab/buy', '/items/buy', '/items/archive', '/quests/claim',
      '/tasks/claim', '/tasks/reroll'].indexOf(path) >= 0) {
      return json({ profile: acc.profile });
    }
    if (path === '/news') return json([]);
    return json({});
  }

  // ------------------------------------------------------------- 拦截
  function parseBody(init) {
    if (!init || !init.body) return null;
    try { return JSON.parse(init.body); } catch (e) { return null; }
  }

  function tokenOf(init) {
    var h = (init && init.headers) || {};
    var auth = null;
    if (typeof h.get === 'function') auth = h.get('Authorization');
    else if (h.Authorization) auth = h.Authorization;
    else if (h.authorization) auth = h.authorization;
    if (!auth) return '';
    return String(auth).replace(/^Bearer\s+/i, '').trim();
  }

  var origFetch = window.fetch ? window.fetch.bind(window) : null;

  window.fetch = function (input, init) {
    var url;
    try {
      url = typeof input === 'string' ? input : (input && input.url) || String(input);
    } catch (e) {
      return origFetch ? origFetch(input, init) : Promise.reject(e);
    }
    var u;
    try { u = new URL(url, location.href); } catch (e) { return origFetch(input, init); }

    if (u.origin !== location.origin || !API.test(u.pathname)) {
      return origFetch ? origFetch(input, init) : Promise.reject(new Error('offline'));
    }
    var method = ((init && init.method) || 'GET').toUpperCase();
    load();
    try {
      return Promise.resolve(handle(u.pathname, u.searchParams, method, parseBody(init), tokenOf(init)));
    } catch (e) {
      return Promise.reject(e);
    }
  };

  // 首次载入时确保状态结构存在
  load();
})();
